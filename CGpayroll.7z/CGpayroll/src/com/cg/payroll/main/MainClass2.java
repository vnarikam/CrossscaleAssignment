package com.cg.payroll.main;

import com.cg.payroll.beans.Associate1;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

public class MainClass2{

	public static void main(String[] args) {
		Associate1 associate =searchAssociate("pavan");
		if(associate!=null)
		System.out.println(associate.getAssociateId());
		else
		System.out.println("not found");	
	}
public static Associate1 searchAssociate(String Name){
	Associate1 associates[] =new Associate1[3];
	associates[0]=new Associate1(199,123666,"pavan","kalyan","ece","analyst","BCKPT3639R","siva@gamil.com");
	associates[1]=new Associate1(222,1238951,"surya","ece","depa","analyst","BPKTGG3444","surya@gamil.com");
	for(Associate1 associate:associates){
		if( associate!=null&&associate.getFirstName()==Name&&associate.getYearlyInvestmentUnder80C()>15000 )
			return associate;
	}
	return null;
}
}
